package stepdefinitions;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.testng.Assert;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.Checkout;
import utilities.CommonMethods;
import utilities.configreader;

public class checkout_steps extends CommonMethods {

    Checkout checkoutPage;
	configreader config = new configreader();
	Logger log = Logger.getLogger(checkout_steps.class);

    @When("the user enters shipping details")
    public void the_user_enters_shipping_details() {
        checkoutPage = new Checkout(dr);
    	String first = config.getProperty("fn");
        String last = config.getProperty("ln");
        String pincode = config.getProperty("pin");
        String address1 = config.getProperty("address1");
        String address2 = config.getProperty("address2");
        String city = config.getProperty("cityname");
        String email = config.getProperty("email");
        String phone = config.getProperty("phoneno");
        checkoutPage.shipping(first, last, pincode, address1, address2, city, email, phone);
        log.info("Entered Shipping details");
    }

    @When("the user proceeds with the payment")
    public void the_user_proceeds_with_the_payment() {
        checkoutPage.paymentprocess();
        log.info("Click continue to payment");
    }
    
    @Then("the user enter into the payment page")
    public void the_user_enter_into_the_payment_page() {
    	Assert.assertEquals(checkoutPage.paymentdetails(),"PAYMENT");
    }
    
    @When("the user does not enter only one field in shipping details")
    public void the_user_does_not_enter_only_one_field_in_shipping_details() {
        String last = config.getProperty("ln");
        String pincode = config.getProperty("pin");
        String address1 = config.getProperty("address1");
        String address2 = config.getProperty("address2");
        String city = config.getProperty("cityname");
        String email = config.getProperty("email");
        String phone = config.getProperty("phoneno");
    	checkoutPage.shipping2(last,pincode,address1,address2,city,email,phone);
        log.info("Click continue to payment without entering details");
    }
    
    @Then("the error message will be displayed")
    public void the_error_message_will_be_displayed() throws IOException {
    	Assert.assertEquals(checkoutPage.getError(),"Invalid Input");
    	screenshot();
    	log.info("Error message is displayed");
    }
}